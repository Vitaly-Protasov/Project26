The folder for some results
