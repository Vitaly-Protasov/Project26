The full experimantal data can be downloaded from [HERE](https://wustl.app.box.com/s/6lzfkaw00w76f8dmu0axax7441xcrzd9)
