The code depends on [this code](https://github.com/higerra/ridi_imu.git)
