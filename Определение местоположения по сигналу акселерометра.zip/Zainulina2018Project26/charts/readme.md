The charts received in the experiments described in the article. The experiments are implemented in Hyperparameters.ipynb
