The received models were tested on the dataset consisting of the following folders:

1. zhicheng_handheld1,handheld
2. zhicheng_leg1,leg
3. zhicheng_bag1,bag
4. zhicheng_body1,body

Predicted trajectories (with and without additional optimization) are compared with true trajectories.
